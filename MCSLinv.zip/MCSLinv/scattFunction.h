#include "particle.h"
#include <vector>
#include <math.h>

using namespace std;

#pragma once

void scattFunction( Particle&, double, double );
