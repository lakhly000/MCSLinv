#pragma once
#include "layer.h"

double specularR(Layer&);
