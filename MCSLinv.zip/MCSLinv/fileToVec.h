#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

#pragma once

void fileToVec(vector<double>&, const string&);
