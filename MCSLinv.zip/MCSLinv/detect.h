#include "intersect.h"
#include "particle.h"
#include <vector>

using namespace std;

#pragma once

/* This file only holds directives because detect is defined inside of
main.h, within the parallel for loop. */
