#include <iostream>
#include <math.h>
#include <limits>
#include <vector>

using namespace std;

#pragma once

double likelihood( const vector<double>&, const vector<double>& );
