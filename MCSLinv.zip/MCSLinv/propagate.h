#include "newSegSize.h"
#include "particle.h"
#include <iostream>
#include <math.h>
#include <vector>

using namespace std;

#pragma once

/* This file only holds directives because propagate is defined inside of
main.h, within the parallel for loop. */
