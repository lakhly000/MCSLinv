#include "HGDist.h"
#include "particle.h"
#include "roulette.h"
#include "scattFunction.h"
#include <vector>
#include <math.h>

using namespace std;

#pragma once

/* This file only holds directives because scatter is defined inside of
main.h, within the parallel for loop. */
