#include <vector>
#include <math.h>

using namespace std;

#pragma once

void subFromMax( vector<vector<double> >&, unsigned int, unsigned int );
