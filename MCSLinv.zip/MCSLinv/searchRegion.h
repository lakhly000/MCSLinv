#include <vector>

using namespace std;

#pragma once

bool searchRegion( const vector<vector<double> >&, unsigned int, unsigned int, unsigned int,
    unsigned int);
