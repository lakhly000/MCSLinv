#include <vector>
#include <iostream>

using namespace std;

#pragma once

bool discMax( const vector<vector<double> >&, int&, int&,
    unsigned int, unsigned int );
