#include <vector>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

#pragma once

void dataOut( const vector<double>&, int );
