#include "layer.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

#pragma once

bool setParameters(vector<Layer>&, vector<double>&, vector<double>&,
    unsigned int&, unsigned int&, unsigned int&, double&);
