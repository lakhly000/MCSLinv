#include <vector>
#include <math.h>

using namespace std;

#pragma once

void fixARS( vector<vector<vector<double> > >&, int, unsigned int, unsigned int );
