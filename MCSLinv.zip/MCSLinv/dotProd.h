#include <vector>

using namespace std;

#pragma once

double dotProd( const vector<double>& v1, const vector<double>& v2 );
