#include <vector>

using namespace std;

#pragma once

void constructA( vector<vector<double> >&, double, double );
