#include <vector>
#include <iostream>
#include <limits>
#include <math.h>

using namespace std;

#pragma once

void solveForMax( const vector<double>&, double&, double& );
