#include "searchRegion.h"
#include <vector>
#include <math.h>
#include <iostream>

using namespace std;

#pragma once

void findRegion( const vector<vector<double> >&, int&,
    int&, int&, int&, int, int );
