#include <vector>

using namespace std;

#pragma once

void addVec( vector<vector<vector<double> > >&, const vector<vector<vector<double> > >&,
    unsigned int, unsigned int );
