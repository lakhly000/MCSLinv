#include <vector>
#include <iostream>

using namespace std;

#pragma once

void evalMaxGrid( const vector<vector<double> >&, vector<double>&, int&, int& );
