#include "dotProd.h"
#include "particle.h"
#include <math.h>
#include <vector>

using namespace std;

#pragma once

double intersect( double, Particle& );
