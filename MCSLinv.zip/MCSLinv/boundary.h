#include "medInterface.h"
#include "layer.h"
#include "particle.h"
#include <math.h>
#include <vector>

using namespace std;

#pragma once

/* This file only holds directives because boundary is defined inside of
main.h, within the parallel for loop. */
