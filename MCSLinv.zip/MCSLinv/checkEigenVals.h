#include <vector>
#include <iostream>
#include <math.h>

using namespace std;

#pragma once

bool checkEigenVals( const vector<double>& );
